# bde-evidencija

Progressive Web App za evidenciju vožnji i dostava.

## Lokalno pokretanje

1. Instaliraj zavisnosti:
   ```
   npm install
   ```
2. Pokreni razvojni server:
   ```
   npm run dev
   ```

## Deploy

Repozitorij: https://github.com/eldin007b/bde-evidencija.git

Za automatski deploy koristi Vercel, Netlify ili GitHub Pages.
#   D e p l o y m e n t   r e a d y  
 
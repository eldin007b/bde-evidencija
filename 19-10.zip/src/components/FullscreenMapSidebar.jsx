// Archived FullscreenMapSidebar: stub kept to avoid breaking imports.
export default null;

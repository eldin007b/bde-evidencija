import React from 'react';

const AdminPanelContainer = ({ children }) => (
  <div className="admin-panel-container">
    {children}
  </div>
);

export default AdminPanelContainer;

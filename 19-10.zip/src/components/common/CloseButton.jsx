import React from 'react';
import { useNavigate } from 'react-router-dom';

const CloseButton = () => {
  // Globalno skriveno dugme na zahtjev – više se ne renderuje
  return null;
};

export default CloseButton;
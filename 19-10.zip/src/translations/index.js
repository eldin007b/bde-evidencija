import ba from './ba';
import en from './en';
import de from './de';
import si from './si';

const translations = {
  ba,
  en,
  de,
  si
};

export default translations;

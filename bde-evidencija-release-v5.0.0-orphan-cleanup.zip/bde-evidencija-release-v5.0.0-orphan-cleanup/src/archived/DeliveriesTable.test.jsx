// Archived test for DeliveriesTable
export { };

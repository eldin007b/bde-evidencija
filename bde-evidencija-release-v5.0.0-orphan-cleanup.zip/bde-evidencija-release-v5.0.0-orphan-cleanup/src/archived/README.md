Archived components and backups

This folder contains archived copy of older component implementations (backup files).
They were moved here to reduce lint noise. Keep them here for history; remove when safe.

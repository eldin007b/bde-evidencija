// Archived useSimpleDriverAuth
export { };

// Lightweight stub: AdminPanel was archived to reduce duplication.
// The real admin UI lives in `src/screens/AdminPanel.jsx` — this stub keeps older imports working.
export { default } from '../screens/AdminPanel.jsx';
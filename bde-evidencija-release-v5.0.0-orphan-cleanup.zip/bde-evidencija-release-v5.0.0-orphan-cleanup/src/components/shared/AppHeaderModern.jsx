// AppHeaderModern archived — provide a minimal stub so imports succeed
export default function AppHeaderModern() {
  return null;
}
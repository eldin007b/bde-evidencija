// Simple Supabase v1 Function (Node.js)
exports.handler = async (req, res) => {
  res.status(200).json({ message: "Radi! Ovo je v1 Supabase Function." });
};

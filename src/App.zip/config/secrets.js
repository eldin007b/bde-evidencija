// Config fajl za produkciju - NE COMMIT-UJ OVAJ FAJL
export const config = {
  GITHUB_TOKEN: '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',
  GITHUB_REPO: 'eldin007b/gls-scraper',
  WORKFLOW_FILE: 'scraper.yml'
};

export default config;
$a = Get-ChildItem -File
foreach ($file in $a) {
    $newName = $file.Name + ".txt"
    $newPath = Join-Path -Path $file.DirectoryName -ChildPath $newName
    Copy-Item -Path $file.FullName -Destination $newPath
}

